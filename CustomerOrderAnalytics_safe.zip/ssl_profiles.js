'use strict';

const awsCaBundle = require('aws-ssl-profiles');

/**
 * @deprecated
 * Please, use [**aws-ssl-profiles**](https://github.com/mysqljs/aws-ssl-profiles).
 */
exports['Amazon RDS'] = {
  ca: awsCaBundle.ca,
};
