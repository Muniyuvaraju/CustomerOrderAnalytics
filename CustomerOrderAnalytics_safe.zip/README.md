# Customer Order Analytics API (Express + PostgreSQL/MySQL)

Minimal REST API backing the Customer Order Analytics project. Supports PostgreSQL and MySQL for flexibility.

## Prerequisites
- Node.js 18+
- Database: PostgreSQL (pgAdmin/psql) or MySQL (MySQL Workbench)

## Setup
1. Choose DB type in `.env`:
   - `DB_TYPE=postgres` or `DB_TYPE=mysql`
2. Create database and run the provided SQL scripts:
   - PostgreSQL:
     ```
     psql -h <PGHOST> -U <PGUSER> -d <PGDATABASE> -f ../sql/schema.sql
     psql -h <PGHOST> -U <PGUSER> -d <PGDATABASE> -f ../sql/sample_data.sql
     ```
   - MySQL:
     - Use MySQL Workbench (open and run) or CLI:
       ```
       mysql -h <MYSQL_HOST> -P <MYSQL_PORT> -u <MYSQL_USER> -p <MYSQL_DATABASE> < ../sql-mysql/schema.mysql.sql
       mysql -h <MYSQL_HOST> -P <MYSQL_PORT> -u <MYSQL_USER> -p <MYSQL_DATABASE> < ../sql-mysql/sample_data.mysql.sql
       ```
3. Configure `.env`:
   ```
   # DB selection
   DB_TYPE=postgres # or mysql

   # Postgres (if using postgres)
   PGHOST=localhost
   PGPORT=5432
   PGDATABASE=your_database
   PGUSER=your_user
   PGPASSWORD=your_password

   # MySQL (if using mysql)
   MYSQL_HOST=127.0.0.1
   MYSQL_PORT=3306
   MYSQL_DATABASE=your_database
   MYSQL_USER=root
   MYSQL_PASSWORD=your_password

   PORT=3000
   ```
4. Install dependencies:
   ```
   npm install express pg cors dotenv mysql2
   ```
5. Start the API:
   ```
   npm start
   ```
6. Test with Postman (collection in `../postman/CustomerOrderAnalytics.postman_collection.json`). Ensure `{{baseUrl}}` is `http://localhost:3000`.

## Endpoints
- `GET /health` — health check (shows `db` type)
- `GET /customers` — list customers
- `GET /products` — list products
- `POST /orders` — create an order with items (transactional)
- `GET /orders?from=YYYY-MM-DD&to=YYYY-MM-DD` — list orders with totals
- `GET /analytics/top-customers?limit=10` — top customers by revenue

## Notes
- The server auto-handles placeholder differences for PostgreSQL (`$1`) vs MySQL (`?`).
- Extend authentication by adding API key or JWT middleware if needed.