'use strict';

module.exports = {
  NO_CURSOR: 0,
  READ_ONLY: 1,
  FOR_UPDATE: 2,
  SCROLLABLE: 3,
};
