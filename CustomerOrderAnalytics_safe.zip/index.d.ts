import { Long } from "./types.js";
export default Long;
