const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();

const { query, transaction, dbType } = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = parseInt(process.env.PORT || '3000', 10);

// Health
app.get('/health', (req, res) => {
  res.json({ status: 'ok', db: dbType });
});

// Customers
app.get('/customers', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM customers ORDER BY customer_id');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

// Products
app.get('/products', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM products ORDER BY product_id');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Create Order
app.post('/orders', async (req, res) => {
  const { customer_id, order_date, status = 'PLACED', items = [] } = req.body || {};
  if (!customer_id || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'customer_id and items are required' });
  }

  try {
    const result = await transaction(async (conn) => {
      let orderId;
      if (dbType === 'mysql') {
        const r = await conn.query(
          'INSERT INTO orders (customer_id, order_date, status) VALUES (?, COALESCE(?, NOW()), ?)',
          [customer_id, order_date, status]
        );
        orderId = r.insertId;
      } else {
        const r = await conn.query(
          'INSERT INTO orders (customer_id, order_date, status) VALUES ($1, COALESCE($2, NOW()), $3) RETURNING order_id',
          [customer_id, order_date, status]
        );
        orderId = r[0].order_id;
      }

      let total = 0;
      for (const item of items) {
        const { product_id, quantity, unit_price } = item;
        if (!product_id || !quantity || !unit_price) {
          throw new Error('Each item requires product_id, quantity, unit_price');
        }
        total += quantity * unit_price;
        if (dbType === 'mysql') {
          await conn.query(
            'INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)',
            [orderId, product_id, quantity, unit_price]
          );
        } else {
          await conn.query(
            'INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES ($1, $2, $3, $4)',
            [orderId, product_id, quantity, unit_price]
          );
        }
      }
      return { orderId, total };
    });

    res.status(201).json({ order_id: result.orderId, total: result.total });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create order', details: err.message });
  }
});

// List Orders with totals (optional date range)
app.get('/orders', async (req, res) => {
  const { from, to } = req.query;
  let sql = `
    SELECT o.order_id, o.customer_id, o.order_date, o.status,
           COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.order_id
  `;
  const params = [];
  if (from && to) {
    if (dbType === 'mysql') {
      sql += ' WHERE o.order_date BETWEEN ? AND ?';
    } else {
      sql += ' WHERE o.order_date BETWEEN $1 AND $2';
    }
    params.push(from, to);
  }
  sql += ' GROUP BY o.order_id, o.customer_id, o.order_date, o.status ORDER BY o.order_date DESC';

  try {
    const rows = await query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Analytics: Top Customers
app.get('/analytics/top-customers', async (req, res) => {
  const limit = parseInt(req.query.limit || '10', 10);
  try {
    let sql;
    let params;
    if (dbType === 'mysql') {
      sql = `SELECT c.customer_id, c.full_name,
                     SUM(oi.quantity * oi.unit_price) AS total_revenue
              FROM customers c
              JOIN orders o ON o.customer_id = c.customer_id
              JOIN order_items oi ON oi.order_id = o.order_id
              GROUP BY c.customer_id, c.full_name
              ORDER BY total_revenue DESC
              LIMIT ?`;
      params = [limit];
    } else {
      sql = `SELECT c.customer_id, c.full_name,
                     SUM(oi.quantity * oi.unit_price) AS total_revenue
              FROM customers c
              JOIN orders o ON o.customer_id = c.customer_id
              JOIN order_items oi ON oi.order_id = o.order_id
              GROUP BY c.customer_id, c.full_name
              ORDER BY total_revenue DESC
              LIMIT $1`;
      params = [limit];
    }

    const rows = await query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
});