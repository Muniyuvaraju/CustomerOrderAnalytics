# Power BI Setup — Customer Order Analytics (MySQL)

This guide connects Power BI Desktop to your MySQL database (`yuavarj1`) and builds a clean analytics dashboard.

## Prerequisites
- Power BI Desktop (latest)
- MySQL Connector/NET 8.0+ installed on Windows
  - If Power BI shows “We couldn't find any installed MySQL drivers”, install MySQL Connector/NET and restart Power BI.
- Your MySQL credentials:
  - Host: `127.0.0.1`
  - Port: `3306`
  - User: `root`
  - Password: `root1`
  - Database: `yuavarj1`

## Connect to MySQL
1. Open Power BI Desktop.
2. Get Data → MySQL database.
3. Server: `127.0.0.1`; Database: `yuavarj1`.
4. Data connectivity mode:
   - Import (simpler and faster for demos), or
   - DirectQuery (live queries; good for larger data/handoff to Service).
5. Authentication: Username `root`; Password `root1` → Connect.
6. Select tables: `customers`, `products`, `orders`, `order_items` → Load.

## Model Relationships
- One-to-many:
  - `customers[customer_id]` → `orders[customer_id]`
  - `orders[order_id]` → `order_items[order_id]`
  - `products[product_id]` → `order_items[product_id]`
- Ensure cross-filter direction is Single (default).

## Date Table (recommended)
Create a Date table for time intelligence:
- Modeling → New table:
```
Date = CALENDAR(MIN(orders[order_date]), MAX(orders[order_date]))
```
- Add columns:
```
Year = YEAR(Date[Date])
Month = FORMAT(Date[Date], "YYYY-MM")
MonthName = FORMAT(Date[Date], "MMM")
```
- Create relationship: `Date[Date]` → `orders[order_date]`.

## Measures (DAX)
Create in Modeling → New measure (see `powerbi/DAX_measures.txt` for copy/paste):
- `Revenue = SUMX(order_items, order_items[quantity] * order_items[unit_price])`
- `Orders = DISTINCTCOUNT(orders[order_id])`
- `AOV = DIVIDE([Revenue], [Orders])`
- `Units Sold = SUM(order_items[quantity])`
- `Customer Revenue = SUMX(RELATEDTABLE(order_items), order_items[quantity] * order_items[unit_price])`
- `Monthly Revenue = [Revenue]` (use Date axis with Month hierarchy)

## Visuals
- KPI Cards: `[Revenue]`, `[AOV]`, `[Orders]`
- Bar Chart: Top Customers → Axis `customers[full_name]`, Value `[Customer Revenue]`, sort by `[Customer Revenue]` desc
- Line Chart: Monthly Revenue → Axis `Date[Month]`, Value `[Revenue]`
- Table: Product Performance → Columns `products[product_name]`, `products[category]`, Measures `[Units Sold]`, `[Revenue]`

## Optional: Use Native SQL (Advanced)
When connecting (Get Data → MySQL), open Advanced options → paste SQL from `sql-mysql/analytics_queries.mysql.sql` to import pre-aggregated results, e.g. monthly revenue.

## Publish & Refresh (Power BI Service)
- Publish your report from Power BI Desktop.
- Install and configure On-premises data gateway (Personal or Standard) to refresh MySQL data.
- In Power BI Service: Dataset settings → Data source credentials → set MySQL creds → schedule refresh.

## Troubleshooting
- Driver not found: Install MySQL Connector/NET and restart.
- Access denied: Verify `root1` password, and that `yuavarj1` exists (run schema + sample scripts).
- Empty visuals: Confirm `order_items` has rows, relationships are active, and measures reference correct tables.