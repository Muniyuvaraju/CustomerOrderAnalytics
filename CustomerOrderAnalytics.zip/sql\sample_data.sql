-- Sample data for demo/testing

-- Customers
INSERT INTO customers (full_name, email) VALUES
  ('Asha Kumar','asha.kumar@example.com'),
  ('Vikram Rao','vikram.rao@example.com'),
  ('Neha Patel','neha.patel@example.com'),
  ('Rahul Singh','rahul.singh@example.com');

-- Products
INSERT INTO products (product_name, category, unit_price) VALUES
  ('Wireless Mouse','Accessories',799.00),
  ('Mechanical Keyboard','Accessories',3499.00),
  ('USB-C Charger','Accessories',999.00),
  ('Gaming Laptop','Computers',74999.00),
  ('27" Monitor','Computers',13999.00);

-- Orders (use explicit order_date for predictable results)
INSERT INTO orders (customer_id, order_date, status) VALUES
  (1, NOW() - INTERVAL '45 days', 'PLACED'),
  (2, NOW() - INTERVAL '30 days', 'SHIPPED'),
  (1, NOW() - INTERVAL '20 days', 'PLACED'),
  (3, NOW() - INTERVAL '10 days', 'PLACED');

-- Order Items
-- Order 1
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
  (1, 1, 2, 799.00),
  (1, 3, 1, 999.00);
-- Order 2
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
  (2, 4, 1, 74999.00);
-- Order 3
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
  (3, 2, 1, 3499.00),
  (3, 3, 2, 999.00);
-- Order 4
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
  (4, 5, 1, 13999.00);