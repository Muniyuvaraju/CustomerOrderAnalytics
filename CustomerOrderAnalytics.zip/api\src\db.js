const dotenv = require('dotenv');
dotenv.config();

const dbType = (process.env.DB_TYPE || 'postgres').toLowerCase();

let pool;
let query;
let transaction;

if (dbType === 'mysql') {
  const mysql = require('mysql2/promise');
  pool = mysql.createPool({
    host: process.env.MYSQL_HOST || process.env.PGHOST || '127.0.0.1',
    port: parseInt(process.env.MYSQL_PORT || '3306', 10),
    database: process.env.MYSQL_DATABASE || process.env.PGDATABASE || 'test',
    user: process.env.MYSQL_USER || process.env.PGUSER || 'root',
    password: process.env.MYSQL_PASSWORD || process.env.PGPASSWORD || '',
    waitForConnections: true,
    connectionLimit: 10,
  });

  query = async (sql, params = []) => {
    const [rows] = await pool.execute(sql, params);
    return rows;
  };

  transaction = async (fn) => {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const result = await fn({
        query: async (sql, params = []) => {
          const [rows] = await conn.execute(sql, params);
          return rows;
        },
      });
      await conn.commit();
      return result;
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  };
} else {
  const { Pool } = require('pg');
  pool = new Pool({
    host: process.env.PGHOST || 'localhost',
    port: parseInt(process.env.PGPORT || '5432', 10),
    database: process.env.PGDATABASE || 'postgres',
    user: process.env.PGUSER || 'postgres',
    password: process.env.PGPASSWORD || '',
    max: 10,
    idleTimeoutMillis: 30000,
  });

  query = async (sql, params = []) => {
    const res = await pool.query(sql, params);
    return res.rows;
  };

  transaction = async (fn) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn({
        query: async (sql, params = []) => {
          const res = await client.query(sql, params);
          return res.rows ? res.rows : res;
        },
      });
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  };
}

module.exports = { pool, query, transaction, dbType };