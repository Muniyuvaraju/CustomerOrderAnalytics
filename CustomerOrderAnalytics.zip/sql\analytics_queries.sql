-- Analytics Queries

-- 1) Monthly Revenue
SELECT DATE_TRUNC('month', o.order_date) AS month,
       SUM(oi.quantity * oi.unit_price) AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
GROUP BY 1
ORDER BY 1;

-- 2) Top Customers by Revenue
SELECT c.customer_id, c.full_name,
       SUM(oi.quantity * oi.unit_price) AS total_revenue
FROM customers c
JOIN orders o ON o.customer_id = c.customer_id
JOIN order_items oi ON oi.order_id = o.order_id
GROUP BY 1,2
ORDER BY total_revenue DESC
LIMIT 10;

-- 3) Category Performance
SELECT p.category,
       SUM(oi.quantity) AS units_sold,
       SUM(oi.quantity * oi.unit_price) AS revenue
FROM products p
JOIN order_items oi ON oi.product_id = p.product_id
GROUP BY 1
ORDER BY revenue DESC;

-- 4) Average Order Value (AOV)
SELECT AVG(order_total) AS avg_order_value
FROM (
  SELECT o.order_id,
         SUM(oi.quantity * oi.unit_price) AS order_total
  FROM orders o
  JOIN order_items oi ON oi.order_id = o.order_id
  GROUP BY o.order_id
) t;

-- 5) Repeat Customers (>= 2 orders)
SELECT c.customer_id, c.full_name,
       COUNT(DISTINCT o.order_id) AS order_count
FROM customers c
JOIN orders o ON o.customer_id = c.customer_id
GROUP BY 1,2
HAVING COUNT(DISTINCT o.order_id) >= 2
ORDER BY order_count DESC;